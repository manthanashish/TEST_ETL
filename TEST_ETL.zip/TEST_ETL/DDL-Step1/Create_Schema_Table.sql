--- Create Internal  Schema-------------
create schema precampaign_etl_test;

----Create precampaign_etl.WMK_DISC_PROG_SEGMENT_MKTG Table
CREATE TABLE precampaign_etl.test
(
DAYPART varchar(128),
ACCT_NBR varchar(128),
EACC_NBR varchar(128),
ACCOUNT_STATUS varchar(128),
RESIDENTIAL_IND varchar(128),
LINEAR_FLAG varchar(128),
ACTIVE_FLAG varchar(128),
MESSAGING_TYPE varchar(128),
NETWORK_ROLLUP_SYMBOL varchar(128),
FULL_NETWORK_TITLE varchar(128),
SYSCODE varchar(128),
TIERTYPE varchar(128),
IMPRESSIONS INTEGER,
SEGMENT varchar(128),
AIDB_PERIOD varchar(128),
EXPERIANCC_PERIOD varchar(128),
PROGRAMMER_NAME varchar(128),
PERIOD varchar(128), 
CAMPAIGN varchar(128), 
SEGMENT_ID varchar(128),
Segment_Advertiser varchar(128)
);
