----Insert into precampaign_etl.WMK_DISC_PROG_SEGMENT_MKTG----

insert into precampaign_etl.test
select 
SDP.DAYPARTS_NAME as DAYPART,
'NoValue' AS ACCT_NBR,
EV.ACCT_NBR AS EACC_NBR,
'' as ACCOUNT_STATUS,
'' as AI_SUBSCRIBER_TYPE,
EV.LINEAR_FLAG,
EV.ACTIVE_FLAG,
'NoValue' as MESSAGING_TYPE,
C.NETWORK_ROLLUP_SYMBOL,
C.FULL_NETWORK_TITLE,
EV.SYSCODE,
C.tier_flag as TIERTYPE,
COUNT(UNIT_ID) AS IMPRESSIONS,
'' as SEGMENT,
'' as AIDB_PERIOD,
'' as EXPERIANCC_PERIOD,
SDP.PROGRAMMER_NAME AS PROGRAMMER_NAME,
'2016_Q4_BROADCAST_QUARTER' AS PERIOD,
'USAA' AS CAMPAIGN, 
'' as SEGMENT_ID,
'' as Segment_Advertiser
from rs_spectrum_athena.wmk_int_oadc_postge_hist_parquet_poc EV
join rs_spectrum_precampaign.dim_mktg_network_prq C
ON EV.SOURCE_ID=C.SOURCE_ID
JOIN rs_spectrum_precampaign.dim_prog_dayparts_int_prq SDP
--modified join as per redshift
ON (TRIM(SDP.DAY_OF_WEEK) = to_char(to_timestamp (TRIM(EV.STARTTIME), 'yyyy-MM-dd hh:mi:ss'),'Day'))
WHERE EV.acct_nbr not in (
        SELECT acct_nbr FROM rs_spectrum_athena.progplus_postge_optout_prqt_snpy)
AND EV.BROADCAST_MONTH_DERIVED BETWEEN '201610' AND '201612'
AND EV.LINEAR_FLAG = '1' 
AND C.NETWORK_ROLLUP_SYMBOL IN ('AHC','APL','DISC','DSE','ID','TLC','Destination America'
,'Science Channel','Discovery Familia','Discovery Family', 'Discovery Life', 'Velocity')
AND SDP.PROGRAMMER_NAME = 'DISC'
AND (SUBSTRING(EV.STARTTIME,12,8) BETWEEN SDP.DAYPART_START_TIME AND SDP.DAYPART_END_TIME)
GROUP BY SDP.DAYPARTS_NAME,
         EV.ACCT_NBR,
         EV.LINEAR_FLAG,
         EV.ACTIVE_FLAG,
         C.NETWORK_ROLLUP_SYMBOL,
         C.FULL_NETWORK_TITLE,
         EV.SYSCODE,
         C.tier_flag,
         SDP.PROGRAMMER_NAME;

