---Update precampaign_etl.WMK_DISC_PROG_SEGMENT_MKTG  segment values---

update precampaign_etl.WMK_DISC_PROG_SEGMENT_MKTG set ACCOUNT_STATUS = abc
RESIDENTIAL_IND=AIDB_AI_SUBSCRIBER_TYPE,
Segment_Advertiser=CASE EV.EACC_NBR WHEN HH.aidb_CUSTOMER_ACCOUNT_NUMBER THEN 'Y' ELSE 'N' END,
segment='abc',
aidb_period='2xxx8',
experiancc_period='xxx',
segment_ID='xxxx1111''
from precampaign_etl.WMK_DISC_PROG_SEGMENT_MKTG EV
join
rs_spectrum_athena.aidb_expcc_match_ext_uniq_prq_snpy HH
on EV.EACC_NBR=HH.aidb_CUSTOMER_ACCOUNT_NUMBER
where EV.CAMPAIGN='USAA' AND HH.aidb_broadcast_month_derived='201708'
AND HH.aidb_ai_subscriber_type='RES'
AND ((HH.EXPCC_EB_LUI_ACTIVE_MILITARY='Y' OR HH.EXPCC_EB_LIF_ACTIVE_MILITARY='Y') 
OR (HH.EXPCC_EB_LUI_RETIRED_MILITARY='Y' OR HH.EXPCC_EB_LIF_VETERAN='Y'));

update precampaign_etl.WMK_DISC_PROG_SEGMENT_MKTG set segment=
(case when segment='' then 'Novalue' else segment end ),
segment_id=(case when segment_ID='' then 'Novalue' else segment_ID end )
where CAMPAIGN='xxx'
